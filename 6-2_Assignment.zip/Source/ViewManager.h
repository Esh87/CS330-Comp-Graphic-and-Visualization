#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include "GLFW/glfw3.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

class ViewManager
{
public:
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // prepares the view + projection matrices each frame
    void PrepareSceneView();

    // ? ADD THESE GETTERS ?
    glm::mat4 GetViewMatrix() const { return m_viewMatrix; }
    glm::mat4 GetProjectionMatrix() const { return m_projectionMatrix; }
    glm::vec3 GetCameraPosition() const { return m_cameraPosition; }

private:
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;

    void ProcessKeyboardEvents();

    // ? ADD THESE PRIVATE VARIABLES ?
    glm::mat4 m_viewMatrix;
    glm::mat4 m_projectionMatrix;
    glm::vec3 m_cameraPosition;

    // camera object
    Camera m_camera;
};